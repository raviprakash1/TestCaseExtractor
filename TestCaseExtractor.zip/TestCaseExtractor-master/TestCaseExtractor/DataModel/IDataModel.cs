﻿namespace TestCaseExtractor.DataModel
{
    public interface IDataModel
    {
    }
}